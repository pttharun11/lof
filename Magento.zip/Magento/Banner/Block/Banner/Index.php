<?php
/**
 * Copyright © 2015 Magento . All rights reserved.
 */
namespace Magento\Banner\Block\Banner;
use Magento\Banner\Block\BaseBlock;
class Index extends BaseBlock
{
	public $hello='Hello World';
	
}
