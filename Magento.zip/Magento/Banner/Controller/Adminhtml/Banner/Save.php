<?php
namespace Magento\Banner\Controller\Adminhtml\Banner;
use Magento\Framework\App\Filesystem\DirectoryList;
class Save extends \Magento\Backend\App\Action
{

    protected $_fileUploaderFactory;
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
	public function execute()
    {
		
        $data = $this->getRequest()->getParams();
        if ($data) {
            $model = $this->_objectManager->create('Magento\Banner\Model\Banner');
		
             if(isset($_FILES['banner']['name']) && $_FILES['banner']['name'] != '') {
				try {
                    $this->_fileUploaderFactory = $this->_objectManager->get('Magento\MediaStorage\Model\File\UploaderFactory');
                    $uploader = $this->_fileUploaderFactory->create(['fileId' => 'banner']);
                    $uploader->setAllowedExtensions(['jpg', 'jpeg','png']);
                    $uploader->setAllowRenameFiles(false);
                    $uploader->setFilesDispersion(false);
                    $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')
                        ->getDirectoryRead(DirectoryList::MEDIA);
                    $path           = $mediaDirectory->getAbsolutePath('bannerslider/images/');

                    $result = $uploader->save($path);

                    $data['banner'] = isset($result['file']) ? $result['file'] : null;

				} catch (Exception $e) {
					$data['banner'] = $_FILES['image']['name'];
				}
			}
			else{
				$data['banner'] = $data['banner']['value'];
			}
			$id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }
			
            $model->setData($data);
			
            try {
                $model->save();
                $this->messageManager->addSuccess(__('Banner Image uploaded successfully'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('*/*/edit', array('id' => $model->getId(), '_current' => true));
                    return;
                }
                $this->_redirect('*/*/');
                return;
            } catch (\Magento\Framework\Model\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the banner.'));
            }

            $this->_getSession()->setFormData($data);
            $this->_redirect('*/*/edit', array('banner_id' => $this->getRequest()->getParam('banner_id')));
            return;
        }
        $this->_redirect('*/*/');
    }
}
