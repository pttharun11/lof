<?php

namespace Magento\Banner\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class Save implements ObserverInterface {
    public function execute(\Magento\Framework\Event\Observer $observer) {

       
    }
}